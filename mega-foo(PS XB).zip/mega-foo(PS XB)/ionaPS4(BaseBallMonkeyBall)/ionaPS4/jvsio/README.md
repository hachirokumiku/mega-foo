# JVSIO

JVSIO is a library for Arduino to handle JVS - JAMMA Video Standard - Bus v3.

## Supported Boards / Devices
 - Arduino Nano
 - MightyCore
 - SparkFun Pro Micro (thanks to [@hnakai0909](https://github.com/hnakai0909))

## Applications that uses this library

 - [iona](https://github.com/toyoshim/iona)
 - [iona-346](https://github.com/toyoshim/iona-346)
 - [iona-js](https://github.com/toyoshim/iona-js)
 - (more ... let me know!)
